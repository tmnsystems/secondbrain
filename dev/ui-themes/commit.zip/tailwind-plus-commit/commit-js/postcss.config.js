module.exports = {
  plugins: {
    '@tailwindcss/postcss': {},
  },
}
